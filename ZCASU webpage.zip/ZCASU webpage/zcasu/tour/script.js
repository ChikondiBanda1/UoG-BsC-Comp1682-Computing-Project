var viewer = pannellum.viewer('panorama', {
    "default": {
        "firstScene": "levy",
        "sceneFadeDuration": 1000
    },

    "scenes": {
        "levy": {
            "title": "Levy Mwanawasa Building",
            "hfov": 110,
            "pitch": -3,
            "yaw": 0,
            "type": "equirectangular",
            "panorama": "./images/entrance.jpg",
            "hotSpots": [
                {
                    "pitch": -0.6,
                    "yaw": 65,
                    "type": "scene",
                    "text": "Basketball Court",
                    "sceneId": "basketball",
                    "targetYaw": -23,
                    "targetPitch": 2
                },
                {
                    "pitch": 0,
                    "yaw": -21,
                    "type": "scene",
                    "sceneId": "corridor"
                }
            ]
        },

        "corridor": {
            "title": "George Sokota Entrance",
            "hfov": 110,
            "pitch": -3,
            "yaw": 0,
            "type": "equirectangular",
            "panorama": "./images/corridor.jpg",
            "hotSpots": [
                {
                    "pitch": 0,
                    "yaw": 15,
                    "type": "scene",
                    "text": "First Floor",
                    "sceneId": "first"
                }
            ]
        },

        "basketball": {
            "title": "Basketball Court",
            "hfov": 110,
            "pitch": -3,
            "yaw": 0,
            "type": "equirectangular",
            "panorama": "./images/basketball_court.jpg",
            "hotSpots": [
                {
                    "pitch": -0.6,
                    "yaw": 120,
                    "type": "scene",
                    "text": "ODel",
                    "sceneId": "odel",
                    "targetYaw": -23,
                    "targetPitch": 2
                },
                {
                    "pitch": 0,
                    "yaw": -131,
                    "type": "scene",
                    "sceneId": "levy"
                }
            ]
        },

        "first": {
            "title": "First Floor",
            "hfov": 110,
            "pitch": -3,
            "yaw": 0,
            "type": "equirectangular",
            "panorama": "./images/first_floor.jpg",
            "hotSpots": [
                {
                    "pitch": -0.6,
                    "yaw": 50,
                    "type": "info",
                    "text": "Student Admin",
                    "targetYaw": -23,
                    "targetPitch": 2
                },
                {
                    "pitch": -3,
                    "yaw": 5,
                    "type": "scene",
                    "text": "Basketball Court",
                    "sceneId": "basketball"
                },
                {
                    "pitch": 0,
                    "yaw": -50,
                    "type": "scene",
                    "text": "Third Floor",
                    "sceneId": "hod"
                },
                {
                    "pitch": -2.5,
                    "yaw": 15,
                    "type": "info",
                    "text": "Finance Office",
                }
            ]
        },

        "odel": {
            "title": "ODel Building",
            "hfov": 110,
            "pitch": -3,
            "yaw": 0,
            "type": "equirectangular",
            "panorama": "./images/odel.jpg",
            "hotSpots": [
                {
                    "pitch": 0,
                    "yaw": 50,
                    "type": "scene",
                    "sceneId": "levy"
                }
            ]
        },

        "hod": {
            "title": "Third Floor - Heads of Departments",
            "hfov": 110,
            "pitch": 30,
            "yaw": 0,
            "panorama": "./images/hods.jpg",
            "hotSpots": [
                {
                    "pitch": 40,
                    "yaw": 10,
                    "type": "scene",
                    "text": "First floor",
                    "sceneId": "first"
                }
            ]
        },
    },



    
    "autoLoad": true,
    "autoRotate": 2
});

// Make buttons work
document.getElementById('pan-up').addEventListener('click', function(e) {
    viewer.setPitch(viewer.getPitch() + 10);
});
document.getElementById('pan-down').addEventListener('click', function(e) {
    viewer.setPitch(viewer.getPitch() - 10);
});
document.getElementById('pan-left').addEventListener('click', function(e) {
    viewer.setYaw(viewer.getYaw() - 20);
});
document.getElementById('pan-right').addEventListener('click', function(e) {
    viewer.setYaw(viewer.getYaw() + 20);
});
document.getElementById('zoom-in').addEventListener('click', function(e) {
    viewer.setHfov(viewer.getHfov() - 10);
});
document.getElementById('zoom-out').addEventListener('click', function(e) {
    viewer.setHfov(viewer.getHfov() + 10);
});
document.getElementById('fullscreen').addEventListener('click', function(e) {
    viewer.toggleFullscreen();
});

        // Function to go back
        function previous() {
            window.history.back();
        }

        // Add event listener to the back button
        document.getElementById("back").addEventListener("click", previous);