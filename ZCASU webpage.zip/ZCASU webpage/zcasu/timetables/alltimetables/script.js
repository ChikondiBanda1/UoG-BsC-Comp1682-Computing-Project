const popupBtns = document.querySelectorAll(".option");

popupBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        Notification.requestPermission().then(perm => {
            if (perm === "granted") {
                new Notification("You have selected")
            }
        });
    });
});

popupBtn.forEach(linkElement => {
    linkElement.addEventListener("click", function(event) {
        event.preventDefault(); // Prevent the link from navigating

        // Get the ID of the clicked link
        const clickedElementId = this.id;

        // Trigger the fade-in effect after a short delay
        setTimeout(function() {
            acidParagraphElement.classList.add('fade-left');
        }, 100);

        // Perform different actions based on the clicked element ID
        if (clickedElementId === "yes") {
            Notification.requestPermission().then(perm => {
                alert(perm)
            })
        } else if (clickedElementId === "no") {
            // Perform a different action for "OtherElement" link
            acidParagraphElement.textContent = "HCl";
        }
    });
});